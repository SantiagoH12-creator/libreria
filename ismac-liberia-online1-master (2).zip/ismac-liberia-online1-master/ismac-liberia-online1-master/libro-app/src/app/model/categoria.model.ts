export interface Categoria{
    idcategoria: number
    categoria: string
    descripcion: string

}
