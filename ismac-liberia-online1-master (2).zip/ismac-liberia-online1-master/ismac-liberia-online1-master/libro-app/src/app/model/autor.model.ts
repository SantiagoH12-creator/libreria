    export interface Autor {
    idAutor: number;
    nombre: string;
    apellido: string;
    pais: string;
    direccion: string;
    telefono: string;
    correo: string;
}