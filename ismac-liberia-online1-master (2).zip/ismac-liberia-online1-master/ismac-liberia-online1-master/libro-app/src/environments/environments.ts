export const enviroment = {
    production: false,
    baseUrl : 'http://localhost:8080/api'
};