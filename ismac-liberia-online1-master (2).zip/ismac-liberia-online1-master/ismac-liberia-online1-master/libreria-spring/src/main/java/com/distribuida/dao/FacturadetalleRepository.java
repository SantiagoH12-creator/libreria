package com.distribuida.dao;

import com.distribuida.model.Facturadetalle;
import org.springframework.data.jpa.repository.JpaRepository;

public interface FacturadetalleRepository extends JpaRepository<Facturadetalle,Integer> {
}

