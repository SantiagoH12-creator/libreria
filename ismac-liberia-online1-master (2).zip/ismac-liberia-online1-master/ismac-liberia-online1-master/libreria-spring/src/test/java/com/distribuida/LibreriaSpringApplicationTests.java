package com.distribuida;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LibreriaSpringApplicationTests {

	@Test
	void contextLoads() {
	}

}
